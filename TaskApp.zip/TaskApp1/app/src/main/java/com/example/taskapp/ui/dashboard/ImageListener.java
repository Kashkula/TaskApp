package com.example.taskapp.ui.dashboard;

import android.widget.ImageView;

public interface ImageListener {
    void setImage(ImageView imageView);
}
